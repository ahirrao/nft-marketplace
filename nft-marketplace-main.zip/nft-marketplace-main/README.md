# nft-marketplace
smart contract on nfts
An NFT smart contract is a self-executing mechanism that implements sale agreements between the owner and buyer. A smart contract also verifies whether the contract terms have been satisfied and can execute these terms without the need for an intermediary or central authority.

Basically, these contracts are simply a set of promises in digital form. For example, if X is true, then Y can be done.

When an NFT is minted (published) on the blockchain, the smart contract automatically assigns ownership of the digital token to the purchaser. And if the owner decides to sell it at some point, the smart contract automatically transfers the ownership of the asset to the new owner once the condition has been met.

Hence, the smart contract verifies that the buyer has sent the seller the requested amount of money before executing the transfer. And this all occurs without the need for an intermediary.

Smart contracts exist within the blockchain (a public ledger) allowing anyone to view the contract terms in addition to the time and date of when the contract was deployed.
